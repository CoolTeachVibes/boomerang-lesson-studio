import { cn } from "@/lib/utils";

export function Brand({ compact = false, className }: { compact?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <path d="M6 9.5C10.2 4.8 18.4 4.1 24 8.2C28.5 11.5 29 18.4 25.2 22.1C21.5 25.7 15 25.4 11.4 21.7" stroke="hsl(var(--primary))" strokeWidth="3.2" strokeLinecap="round" />
        <path d="M6.2 4.8L5.8 10.1L11.1 9.8" stroke="hsl(var(--primary))" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="11" cy="22" r="2.2" fill="hsl(var(--foreground))" />
      </svg>
      {!compact && (
        <span className="leading-none">
          <span className="display-type block text-[17px] font-extrabold tracking-[-0.04em]">Boomerang</span>
          <span className="mt-1 block text-[10px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Lesson Studio</span>
        </span>
      )}
    </span>
  );
}
