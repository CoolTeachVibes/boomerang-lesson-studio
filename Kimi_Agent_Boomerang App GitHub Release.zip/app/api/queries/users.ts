import { eq } from "drizzle-orm";
import { users, type InsertUser } from "@db/schema";
import { getDb } from "./connection";

export async function findUserById(id: number) {
  const [user] = await getDb().select().from(users).where(eq(users.id, id)).limit(1);
  return user ?? null;
}

export async function findUserByEmail(email: string) {
  const [user] = await getDb().select().from(users).where(eq(users.email, email)).limit(1);
  return user ?? null;
}

export async function createUser(data: InsertUser) {
  const [{ id }] = await getDb().insert(users).values(data).$returningId();
  const user = await findUserById(id);
  if (!user) throw new Error("User could not be created");
  return user;
}

export async function touchSignIn(id: number) {
  await getDb().update(users).set({ lastSignInAt: new Date() }).where(eq(users.id, id));
}
