import { phaseMeta, type LessonData, type PhaseKey } from "@contracts/lesson";

export function totalMinutes(data: LessonData) {
  return (Object.keys(phaseMeta) as PhaseKey[]).reduce((sum, key) => sum + data[key].minutes, 0);
}

export function lessonProgress(data: LessonData) {
  const checks = readinessChecks(data);
  return Math.round((checks.filter((check) => check.complete).length / checks.length) * 100);
}

export function readinessChecks(data: LessonData) {
  const selectedGaps = data.gaps.filter((gap) => gap.selected);
  return [
    { id: "engage", label: "Engage creates curiosity without pre-teaching", complete: Boolean(data.engage.activity.trim() && data.engage.instructions.trim()) },
    { id: "a1-task", label: "Activate 1 sets a genuine communication problem", complete: Boolean(data.activate1.activity.trim() && data.activate1.successCriteria.trim()) },
    { id: "gaps", label: "At least one real language gap is captured", complete: data.gaps.length > 0 },
    { id: "study-link", label: "Study responds to a selected Activate 1 gap", complete: selectedGaps.length > 0 && Boolean(data.study.focus.trim()) },
    { id: "study-plan", label: "Study includes form, meaning, and examples", complete: Boolean(data.study.instructions.trim() && data.study.examples.trim()) },
    { id: "a2-task", label: "Activate 2 revisits communication with a new constraint", complete: Boolean(data.activate2.activity.trim() && data.activate2.newConstraints.trim()) },
    { id: "evidence", label: "Success evidence for Activate 2 is defined", complete: Boolean(data.activate2.evidence.trim()) },
    { id: "reflection", label: "Rebel reflection is complete", complete: Boolean(data.reflection.silenceExperience.trim() && data.reflection.engagementShift.trim()) },
  ];
}

export function formatLessonDate(value: string) {
  if (!value) return "Date not set";
  const date = new Date(`${value}T12:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(date);
}

export function statusLabel(status: string) {
  return status === "ready" ? "Ready to teach" : status === "completed" ? "Taught & reflected" : "Draft";
}
