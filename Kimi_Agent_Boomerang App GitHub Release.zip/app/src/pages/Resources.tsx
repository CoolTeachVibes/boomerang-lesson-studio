import { phaseMeta, type PhaseKey } from "@contracts/lesson";
import { ArrowRight, BookOpen, Check, Clipboard, Eye, FileText, MessageSquare, Play, X } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router";

const phaseGuidance: Record<PhaseKey, { move: string; avoid: string }> = {
  engage: { move: "Use a visual, contradiction, or open question to create emotional involvement.", avoid: "Pre-teaching vocabulary or explaining the grammar rule." },
  activate1: { move: "Set a real-world goal. Monitor exact language and communication breakdowns.", avoid: "Interrupting, correcting, or supplying the missing language too soon." },
  study: { move: "Board genuine examples from Activate 1. Shape the lesson around those needs.", avoid: "Teaching the unit you planned before you saw students attempt the task." },
  activate2: { move: "Repeat or evolve the task with new constraints and a reason to communicate.", avoid: "Ending with controlled gap-fills or repeating the exact same script." },
};

export default function Resources() {
  const navigate = useNavigate();
  const [caseView, setCaseView] = useState<"before" | "after">("after");
  const [copied, setCopied] = useState(false);

  async function copyStems() {
    const stems = "Activate 1 observation stems\n• Students wanted to say…\n• Communication broke down when…\n• The exact phrase I heard was…\n• They substituted… because they needed…\n• This need matters for task success because…";
    await navigator.clipboard.writeText(stems);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="mx-auto max-w-[1240px] px-5 pb-20 pt-8 sm:px-8 lg:px-10 lg:pt-10">
      <header className="grid gap-6 border-b pb-8 lg:grid-cols-[1fr_320px] lg:items-end">
        <div><p className="section-label text-primary">Method library</p><h1 className="display-type mt-3 max-w-3xl text-4xl font-extrabold leading-[1.08] sm:text-5xl">From drills to dialogue.</h1><p className="mt-4 max-w-2xl text-[16px] leading-relaxed text-muted-foreground">A practical field guide for flipping the lesson script: let communicative need reveal the teaching point.</p></div>
        <button className="btn-primary chamfer justify-self-start lg:justify-self-end" onClick={() => navigate("/")}>Open my lesson library <ArrowRight className="h-4 w-4" /></button>
      </header>

      <section className="grid gap-8 border-b py-9 lg:grid-cols-[minmax(0,1.35fr)_minmax(280px,0.65fr)]">
        <div className="overflow-hidden rounded-xl bg-[#111]">
          <div className="aspect-video"><iframe className="h-full w-full" src="https://www.youtube-nocookie.com/embed/m1rwJ8bKo-g?hl=es" title="Boomerang ESA lesson reference video" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen /></div>
        </div>
        <div className="flex flex-col justify-center"><Play className="h-6 w-6 text-primary" /><p className="section-label mt-4">Watch first</p><h2 className="display-type mt-2 text-2xl font-bold">See the sequence in motion.</h2><p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">Use the reference video to notice the teacher’s role across phases: when to step back, what evidence to gather, and when targeted teaching becomes useful.</p><div className="mt-5 border-l-2 border-primary pl-4 text-sm"><strong>Viewing question</strong><p className="mt-1 text-muted-foreground">What does the teacher learn from the first attempt that a pre-planned grammar explanation could not reveal?</p></div></div>
      </section>

      <section className="border-b py-9">
        <div className="max-w-2xl"><p className="section-label">The mechanics of the shift</p><h2 className="display-type mt-2 text-3xl font-bold">One arc. Two different kinds of action.</h2><p className="mt-3 text-muted-foreground">Activate phases create the need and use the language. Study lives between them, made precise by evidence.</p></div>
        <div className="mt-7 grid gap-px overflow-hidden rounded-xl border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {(Object.keys(phaseMeta) as PhaseKey[]).map((key) => <article key={key} className="bg-white p-5"><div className="flex items-center justify-between"><span className="display-type flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-xs font-extrabold text-secondary-foreground">{phaseMeta[key].short}</span>{key === "activate1" ? <Eye className="h-5 w-5 text-primary" /> : key === "study" ? <BookOpen className="h-5 w-5 text-primary" /> : <MessageSquare className="h-5 w-5 text-primary" />}</div><h3 className="display-type mt-4 text-lg font-bold">{phaseMeta[key].title}</h3><p className="mt-2 text-sm leading-relaxed">{phaseGuidance[key].move}</p><p className="mt-4 flex gap-2 border-t pt-3 text-xs leading-relaxed text-muted-foreground"><X className="mt-0.5 h-3.5 w-3.5 shrink-0 text-destructive" />{phaseGuidance[key].avoid}</p></article>)}
        </div>
      </section>

      <section className="grid gap-8 border-b py-9 lg:grid-cols-[280px_minmax(0,1fr)]">
        <div><p className="section-label">Presentation case study</p><h2 className="display-type mt-2 text-3xl font-bold">The “Jobs” lesson, transformed.</h2><p className="mt-3 text-sm leading-relaxed text-muted-foreground">The content does not need to disappear. Its role changes: from answers on a worksheet to resources students discover they need.</p><div className="mt-5 inline-flex rounded-lg bg-muted p-1" role="group" aria-label="Case study view"><button className={`min-h-11 rounded-md px-4 text-sm font-bold ${caseView === "before" ? "bg-white shadow-sm" : "text-muted-foreground"}`} onClick={() => setCaseView("before")} aria-pressed={caseView === "before"}>Before</button><button className={`min-h-11 rounded-md px-4 text-sm font-bold ${caseView === "after" ? "bg-white shadow-sm" : "text-muted-foreground"}`} onClick={() => setCaseView("after")} aria-pressed={caseView === "after"}>After</button></div></div>
        {caseView === "before" ? <div className="bg-white p-6 sm:p-8"><span className="section-label">Traditional worksheet</span><h3 className="display-type mt-3 text-2xl font-bold">Fill in the job description.</h3><div className="mt-6 space-y-4 text-lg"><p>A nurse ___ in a hospital.</p><p className="text-muted-foreground">A pilot ___ a plane.</p><p>An engineer ___ machines.</p></div><div className="mt-7 border-t pt-5"><p className="text-sm font-bold">What the teacher learns</p><p className="mt-1 text-sm text-muted-foreground">Whether students can supply a controlled answer when the sentence, verb, and context are already given.</p></div></div> : <div className="bg-primary p-6 text-white sm:p-8"><span className="text-xs font-bold uppercase tracking-[0.13em] text-white/75">Diagnostic role-play</span><h3 className="display-type mt-3 text-2xl font-bold">The career fair has a problem.</h3><p className="mt-4 max-w-xl text-[15px] leading-relaxed text-white/85">One student is a recruiter with an urgent vacancy. The other is a candidate with three non-negotiable needs. They must explain the job, ask follow-up questions, and decide whether to proceed.</p><div className="mt-6 grid gap-4 border-t border-white/25 pt-5 sm:grid-cols-2"><div><p className="text-sm font-bold">Communicative gap</p><p className="mt-1 text-sm text-white/80">Students must describe duties and conditions the teacher has not scripted.</p></div><div><p className="text-sm font-bold">What Study answers</p><p className="mt-1 text-sm text-white/80">The exact verbs, forms, and questions students needed to complete the negotiation.</p></div></div></div>}
      </section>

      <section className="grid gap-8 py-9 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div><p className="section-label">Core reading lens</p><h2 className="display-type mt-2 text-2xl font-bold">Controlled practice ≠ real communication</h2><div className="mt-5 space-y-4 text-[15px] leading-relaxed"><p><strong>A grammar drill controls the answer.</strong> Its main evidence is formal accuracy in a predictable frame.</p><p><strong>A meaning-focused pedagogic tool creates an outcome.</strong> Students choose language to fill an information, opinion, or reasoning gap. Success depends on whether the message achieves its purpose.</p><p className="text-muted-foreground">Use this distinction while reading <em>Controlled Practice vs Real Communication Activities</em>: ask who chooses the language, whether the outcome is predictable, and what the teacher can learn from the attempt.</p></div></div>
        <aside className="border-l-2 border-primary pl-5"><Clipboard className="h-5 w-5 text-primary" /><h3 className="display-type mt-3 text-lg font-bold">Observation stems</h3><p className="mt-2 text-sm text-muted-foreground">Take these into class to make your Activate 1 notes specific and report-ready.</p><ul className="mt-4 space-y-2 text-sm"><li>Students wanted to say…</li><li>Communication broke down when…</li><li>The exact phrase I heard was…</li><li>They substituted… because…</li></ul><button className="btn-secondary mt-5 w-full" onClick={copyStems}>{copied ? <Check className="h-4 w-4 text-green-700" /> : <FileText className="h-4 w-4" />}{copied ? "Copied to clipboard" : "Copy observation stems"}</button></aside>
      </section>
    </div>
  );
}
