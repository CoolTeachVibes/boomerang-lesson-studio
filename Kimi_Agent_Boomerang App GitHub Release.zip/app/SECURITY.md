# Security Policy

## Supported versions

Security fixes are applied to the latest commit on `main`.

## Reporting a vulnerability

Do not disclose vulnerabilities in public GitHub issues. Use the repository owner's private security advisory channel, or contact the owner through the email address listed on their GitHub profile. Include reproduction steps, affected files, and potential impact. Do not include real user data, passwords, session cookies, or production connection strings.

## Deployment checklist

- Generate a unique `APP_SECRET` with at least 32 random characters.
- Use unique database credentials and restrict network access to MySQL.
- Serve the application over HTTPS in production.
- Keep the database and Node dependencies patched.
- Add reverse-proxy rate limiting for a public deployment.
- Back up MySQL before applying migrations.
- Never commit `.env`, session cookies, database dumps, or user reports containing private classroom data.

The application includes in-process login throttling. Distributed or high-traffic deployments should also use an external rate limiter. Email verification and password recovery are not currently included; add them before offering accounts to an untrusted public audience.
