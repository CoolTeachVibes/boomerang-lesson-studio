import type { RouterOutputs } from "@/providers/trpc";

export type LessonRecord = RouterOutputs["lessons"]["byId"];

export type LessonDraft = Pick<
  LessonRecord,
  "id" | "title" | "course" | "topic" | "level" | "classDate" | "studentCount" | "status" | "data"
>;

export type EditorSection = "engage" | "activate1" | "study" | "activate2" | "reflection" | "report";
