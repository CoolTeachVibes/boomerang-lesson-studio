# Contributing

Thank you for improving Boomerang Lesson Studio.

## Development flow

1. Fork the repository and create a focused branch.
2. Follow the local setup in [README.md](README.md).
3. Keep the Boomerang sequence faithful: communication first, Study based on observed need, then a meaningful second attempt.
4. Run `npm run check`, `npm run test`, and `npm run build` before opening a pull request.
5. For UI changes, verify keyboard operation and both desktop and 375px mobile layouts. Include screenshots.
6. For schema changes, commit a generated Drizzle migration and document its effect on existing data. Never force destructive migrations.

## Code guidelines

- Validate every tRPC input with Zod.
- Scope every lesson query by the authenticated user ID.
- Never expose password hashes or session secrets to the browser.
- Do not store lesson records in localStorage; they belong in MySQL.
- Preserve loading, empty, error, and success states for asynchronous workflows.
- Use semantic controls and maintain visible focus states and 44px touch targets.

## Reporting security issues

Do not open a public issue for a vulnerability. Follow [SECURITY.md](SECURITY.md).
