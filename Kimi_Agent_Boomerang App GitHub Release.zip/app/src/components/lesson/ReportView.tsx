import type { LessonDraft } from "@/types/lesson";
import { formatLessonDate, readinessChecks, totalMinutes } from "@/lib/lesson-utils";
import { phaseMeta, type PhaseKey } from "@contracts/lesson";
import { Check, Download, Printer, TriangleAlert } from "lucide-react";

function text(value: string, fallback = "Not yet documented.") {
  return value.trim() || fallback;
}

export function ReportView({ lesson, professorName }: { lesson: LessonDraft; professorName?: string }) {
  const selectedGaps = lesson.data.gaps.filter((gap) => gap.selected);
  const checks = readinessChecks(lesson.data);
  const complete = checks.filter((check) => check.complete).length;
  const allText = [
    lesson.data.engage.activity,
    lesson.data.engage.instructions,
    lesson.data.activate1.activity,
    lesson.data.activate1.instructions,
    lesson.data.study.activity,
    lesson.data.study.instructions,
    lesson.data.study.focus,
    lesson.data.activate2.activity,
    lesson.data.activate2.instructions,
    lesson.data.reflection.silenceExperience,
    lesson.data.reflection.engagementShift,
    lesson.data.reflection.nextTime,
  ].join(" ");
  const wordCount = allText.trim() ? allText.trim().split(/\s+/).length : 0;

  function downloadMarkdown() {
    const phases = (Object.keys(phaseMeta) as PhaseKey[]).map((key) => {
      const phase = lesson.data[key];
      return `### ${phaseMeta[key].title} (${phase.minutes} min)\n${text(phase.activity)}\n\nInstructions: ${text(phase.instructions)}\nMaterials: ${text(phase.materials, "None listed.")}`;
    }).join("\n\n");
    const markdown = `# Transformation Report & Reflection\n\n**${lesson.title}**\n${professorName || "Professor"} · ${lesson.course || "Course not specified"} · ${formatLessonDate(lesson.classDate)}\n\n## 1. Lesson Blueprint\n\n${phases}\n\n## 2. The Linguistic Gap\n\n${selectedGaps.length ? selectedGaps.map((gap) => `- **${gap.type}:** ${gap.observation}${gap.neededLanguage ? ` — needed: ${gap.neededLanguage}` : ""}`).join("\n") : "No gaps selected."}\n\n**How this modified Study:** ${text(lesson.data.study.focus)}\n\n## 3. The Rebel Reflection\n\n**Difficulty staying silent:** ${lesson.data.reflection.silenceDifficulty}/5\n\n${text(lesson.data.reflection.silenceExperience)}\n\n**Student engagement shift:** ${text(lesson.data.reflection.engagementShift)}\n\n**Next time:** ${text(lesson.data.reflection.nextTime)}\n`;
    const url = URL.createObjectURL(new Blob([markdown], { type: "text/markdown;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${lesson.title.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "") || "boomerang-lesson"}-report.md`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div className="no-print mb-6 flex flex-col gap-4 border-y bg-white px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
        <div><p className="text-sm font-bold">{complete} of {checks.length} submission checks complete</p><p className="mt-0.5 text-xs text-muted-foreground">Two-page layout · approximately {wordCount} words</p></div>
        <div className="flex flex-wrap gap-2"><button className="btn-secondary" onClick={downloadMarkdown}><Download className="h-4 w-4" /> Markdown</button><button className="btn-primary" onClick={() => window.print()}><Printer className="h-4 w-4" /> Print / Save PDF</button></div>
      </div>
      {wordCount > 1100 && <div className="no-print mb-6 flex gap-3 border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm text-amber-950"><TriangleAlert className="h-5 w-5 shrink-0" />This draft may exceed two pages. Shorten activity notes while preserving the three required sections.</div>}
      {complete < checks.length && <div className="no-print mb-6 rounded-lg bg-secondary/60 px-4 py-3 text-sm"><strong>Before submitting:</strong> return to the plan to complete {checks.length - complete} remaining {checks.length - complete === 1 ? "check" : "checks"}. Placeholder text is shown below.</div>}

      <div id="transformation-report" className="space-y-6 print:space-y-0">
        <article className="report-sheet mx-auto max-w-[794px] px-6 py-8 sm:px-10 sm:py-12">
          <header className="border-b-2 border-[#21221f] pb-5">
            <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#0064e6]">Disruptive English Teaching · Boomerang ESA</p>
            <h1 className="display-type mt-2 text-3xl font-extrabold leading-tight">Transformation Report<br />& Reflection</h1>
            <div className="mt-5 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4"><div><span className="block text-[#656761]">Professor</span><strong>{professorName || "—"}</strong></div><div><span className="block text-[#656761]">Course</span><strong>{lesson.course || "—"}</strong></div><div><span className="block text-[#656761]">Level</span><strong>{lesson.level || "—"}</strong></div><div><span className="block text-[#656761]">Date</span><strong>{formatLessonDate(lesson.classDate)}</strong></div></div>
          </header>
          <section className="mt-6">
            <div className="flex items-end justify-between gap-4"><div><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#0064e6]">Section 1</p><h2 className="display-type mt-1 text-xl font-bold">The Lesson Blueprint</h2></div><p className="text-xs text-[#656761]">{lesson.topic} · {totalMinutes(lesson.data)} min</p></div>
            <h3 className="display-type mt-4 text-lg font-bold">{lesson.title}</h3>
            <div className="mt-4 space-y-4">
              {(Object.keys(phaseMeta) as PhaseKey[]).map((key) => {
                const phase = lesson.data[key];
                return <div key={key} className="grid grid-cols-[44px_minmax(0,1fr)] gap-3 border-t border-[#deded8] pt-3"><div><span className="display-type text-lg font-extrabold text-[#0064e6]">{phaseMeta[key].short}</span><span className="block text-[10px] text-[#656761]">{phase.minutes} min</span></div><div><h4 className="text-sm font-bold">{phaseMeta[key].title} · {text(phase.activity, "Activity not planned")}</h4><p className="mt-1 whitespace-pre-wrap text-xs leading-relaxed">{text(phase.instructions)}</p><p className="mt-1 text-[11px] text-[#656761]"><strong>Materials:</strong> {text(phase.materials, "None listed")}</p>{key === "activate1" && <p className="mt-1 text-[11px]"><strong>Success:</strong> {text(lesson.data.activate1.successCriteria)}</p>}{key === "activate2" && <p className="mt-1 text-[11px]"><strong>New constraint:</strong> {text(lesson.data.activate2.newConstraints)}</p>}</div></div>;
              })}
            </div>
          </section>
          <footer className="mt-7 flex justify-between border-t border-[#deded8] pt-3 text-[10px] text-[#656761]"><span>Boomerang ESA · E → A1 → S → A2</span><span>1 / 2</span></footer>
        </article>

        <article className="report-sheet mx-auto max-w-[794px] px-6 py-8 sm:px-10 sm:py-12">
          <section>
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#0064e6]">Section 2</p><h2 className="display-type mt-1 text-2xl font-bold">The Linguistic Gap</h2>
            <p className="mt-2 text-xs leading-relaxed text-[#656761]">Observed during Activate 1 without interrupting communication.</p>
            {selectedGaps.length === 0 ? <p className="mt-5 text-sm">No observations selected for the report.</p> : <div className="mt-5 space-y-3">{selectedGaps.map((gap) => <div key={gap.id} className="grid grid-cols-[92px_minmax(0,1fr)] gap-3 border-t border-[#deded8] pt-3 text-xs"><strong className="uppercase text-[#0064e6]">{gap.type}</strong><div><p>{gap.observation}</p>{gap.neededLanguage && <p className="mt-1 text-[#656761]"><strong>Needed:</strong> {gap.neededLanguage}</p>}</div></div>)}</div>}
            <div className="mt-6 bg-[#f0f5fc] p-4"><h3 className="text-sm font-bold">How the evidence modified Study</h3><p className="mt-2 whitespace-pre-wrap text-xs leading-relaxed">{text(lesson.data.study.focus)}</p><p className="mt-3 whitespace-pre-wrap text-xs leading-relaxed"><strong>Board work & examples:</strong> {text(lesson.data.study.examples)}</p></div>
          </section>
          <section className="mt-7 border-t-2 border-[#21221f] pt-5">
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#0064e6]">Section 3</p><h2 className="display-type mt-1 text-2xl font-bold">The Rebel Reflection</h2>
            <div className="mt-4 flex items-center gap-3 text-xs"><strong>Difficulty staying silent</strong><span className="flex gap-1" aria-label={`${lesson.data.reflection.silenceDifficulty} out of 5`}>{[1, 2, 3, 4, 5].map((value) => <span key={value} className={`h-2.5 w-7 ${value <= lesson.data.reflection.silenceDifficulty ? "bg-[#0064e6]" : "bg-[#deded8]"}`} />)}</span><strong>{lesson.data.reflection.silenceDifficulty}/5</strong></div>
            <div className="mt-5 grid gap-5 sm:grid-cols-2"><div><h3 className="text-sm font-bold">My internal experience</h3><p className="mt-2 whitespace-pre-wrap text-xs leading-relaxed">{text(lesson.data.reflection.silenceExperience)}</p></div><div><h3 className="text-sm font-bold">The engagement shift</h3><p className="mt-2 whitespace-pre-wrap text-xs leading-relaxed">{text(lesson.data.reflection.engagementShift)}</p></div></div>
            <div className="mt-5 border-t border-[#deded8] pt-4"><h3 className="text-sm font-bold">Next iteration</h3><p className="mt-2 whitespace-pre-wrap text-xs leading-relaxed">{text(lesson.data.reflection.nextTime)}</p></div>
            <div className="mt-5 border-t border-[#deded8] pt-4"><h3 className="text-sm font-bold">Evidence from Activate 2</h3><p className="mt-2 whitespace-pre-wrap text-xs leading-relaxed">{text(lesson.data.activate2.evidence)}</p></div>
          </section>
          <footer className="mt-7 flex justify-between border-t border-[#deded8] pt-3 text-[10px] text-[#656761]"><span className="flex items-center gap-1"><Check className="h-3 w-3" /> Communication before correction</span><span>2 / 2</span></footer>
        </article>
      </div>
    </div>
  );
}
