import { Field, PhaseFields } from "./Fields";
import { MonitorDialog } from "./MonitorDialog";
import type { LessonData } from "@contracts/lesson";
import { AlertCircle, ArrowRight, Check, Eye, Link2, MessageCircle, Plus, Trash2 } from "lucide-react";
import { useState } from "react";

type EditorProps = { data: LessonData; onChange: (data: LessonData) => void; goTo?: (section: "activate2" | "report") => void };

export function EngageEditor({ data, onChange }: EditorProps) {
  return (
    <div className="space-y-6">
      <div className="flex gap-3 border-y bg-secondary/45 px-4 py-3 text-sm"><MessageCircle className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><p><strong>Emotion before explanation.</strong> Use an image, dilemma, or open question. Do not pre-teach the target vocabulary or grammar.</p></div>
      <PhaseFields value={data.engage} onChange={(engage) => onChange({ ...data, engage })} activityLabel="Curiosity trigger" activityPlaceholder="Show a photo of an unusual workplace. Ask: “What happened here thirty seconds ago?”" />
    </div>
  );
}

export function Activate1Editor({ data, onChange }: EditorProps) {
  const [monitorOpen, setMonitorOpen] = useState(false);
  const phase = data.activate1;
  return (
    <div className="space-y-7">
      <div className="flex flex-col gap-4 border-y bg-primary px-4 py-4 text-white sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-3"><Eye className="mt-0.5 h-5 w-5 shrink-0" /><p className="text-sm"><strong>The rebel rule:</strong> step back, monitor, and write. No interrupting. No correcting.</p></div>
        <button className="inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-bold text-primary transition-transform active:translate-y-px" onClick={() => setMonitorOpen(true)}><Plus className="h-4 w-4" /> Open monitoring mode</button>
      </div>
      <PhaseFields value={phase} onChange={(value) => onChange({ ...data, activate1: { ...phase, ...value } })} activityLabel="Unstructured communicative task" activityPlaceholder="A candidate and employer meet at a career fair. They must agree on a job without a scripted dialogue." />
      <div className="grid gap-5 sm:grid-cols-[180px_minmax(0,1fr)]">
        <Field label="Task format"><select className="field" value={phase.taskType} onChange={(e) => onChange({ ...data, activate1: { ...phase, taskType: e.target.value } })}><option>Role-play</option><option>Problem-solving</option><option>Dilemma</option><option>Information gap</option><option>Simulation</option></select></Field>
        <Field label="What counts as communicative success?" hint="Focus on completing the real-world goal, not grammatical perfection."><textarea className="field min-h-20" value={phase.successCriteria} onChange={(e) => onChange({ ...data, activate1: { ...phase, successCriteria: e.target.value } })} placeholder="Both speakers understand the job conditions and agree on next steps." /></Field>
      </div>
      <GapLog data={data} onChange={onChange} onOpenMonitor={() => setMonitorOpen(true)} />
      <MonitorDialog open={monitorOpen} onOpenChange={setMonitorOpen} gaps={data.gaps} onAdd={(gap) => onChange({ ...data, gaps: [...data.gaps, gap] })} />
    </div>
  );
}

function GapLog({ data, onChange, onOpenMonitor }: EditorProps & { onOpenMonitor: () => void }) {
  return (
    <section className="border-t pt-6">
      <div className="flex items-center justify-between gap-3"><div><h3 className="display-type text-lg font-bold">Linguistic gap log</h3><p className="mt-1 text-sm text-muted-foreground">Capture exact student language. Select the needs that should shape Study.</p></div><button className="icon-button" onClick={onOpenMonitor} aria-label="Add a language gap"><Plus className="h-5 w-5" /></button></div>
      {data.gaps.length === 0 ? (
        <button className="mt-4 flex min-h-24 w-full items-center justify-center gap-2 rounded-lg border border-dashed bg-white px-4 text-sm font-semibold text-muted-foreground transition-colors hover:border-primary hover:text-primary" onClick={onOpenMonitor}><Plus className="h-4 w-4" /> Capture your first observation during Activate 1</button>
      ) : (
        <ul className="mt-4 divide-y border-y">
          {data.gaps.map((gap) => (
            <li key={gap.id} className="flex items-start gap-3 py-4">
              <button className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded border ${gap.selected ? "border-primary bg-primary text-white" : "border-input bg-white"}`} onClick={() => onChange({ ...data, gaps: data.gaps.map((item) => item.id === gap.id ? { ...item, selected: !item.selected } : item) })} aria-label={`${gap.selected ? "Remove" : "Include"} gap in Study`} aria-pressed={gap.selected}>{gap.selected && <Check className="h-4 w-4" />}</button>
              <div className="min-w-0 flex-1"><span className="text-[11px] font-bold uppercase tracking-[0.12em] text-muted-foreground">{gap.type}</span><p className="mt-0.5 text-[15px]">{gap.observation}</p>{gap.neededLanguage && <p className="mt-1 text-sm text-muted-foreground"><strong>Needed:</strong> {gap.neededLanguage}</p>}</div>
              <button className="icon-button h-9 w-9" onClick={() => onChange({ ...data, gaps: data.gaps.filter((item) => item.id !== gap.id) })} aria-label={`Delete observation: ${gap.observation}`}><Trash2 className="h-4 w-4" /></button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export function StudyEditor({ data, onChange, goTo }: EditorProps) {
  const phase = data.study;
  const selected = data.gaps.filter((gap) => gap.selected);
  return (
    <div className="space-y-7">
      <div className="flex gap-3 border-y bg-secondary/45 px-4 py-3 text-sm"><Link2 className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><p><strong>Build from the evidence.</strong> Teach only what helps students repair or extend the communication you just observed.</p></div>
      <section>
        <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="display-type text-lg font-bold">Gaps brought to the board</h3><span className="text-xs font-bold text-primary">{selected.length} selected</span></div>
        {data.gaps.length === 0 ? <div className="mt-3 border-l-2 border-amber-500 bg-amber-50 px-4 py-3 text-sm text-amber-950">No Activate 1 observations yet. Teach after the first task, then return here to choose real gaps.</div> : (
          <div className="mt-3 space-y-2">{data.gaps.map((gap) => <label key={gap.id} className="flex min-h-12 cursor-pointer items-start gap-3 rounded-lg bg-white px-3 py-3"><input type="checkbox" className="mt-1 h-4 w-4 accent-[hsl(var(--primary))]" checked={gap.selected} onChange={() => onChange({ ...data, gaps: data.gaps.map((item) => item.id === gap.id ? { ...item, selected: !item.selected } : item) })} /><span className="text-sm"><span className="mr-2 font-bold uppercase text-muted-foreground">{gap.type}</span>{gap.observation}{gap.neededLanguage && <span className="block text-muted-foreground">Needed: {gap.neededLanguage}</span>}</span></label>)}</div>
        )}
      </section>
      <Field label="Targeted Study focus" hint="Name the language need in response to the selected observations."><textarea className="field min-h-24" value={phase.focus} onChange={(e) => onChange({ ...data, study: { ...phase, focus: e.target.value } })} placeholder="Students avoided third-person singular forms when describing routines. Focus on meaning + form: he/she/it goes…" /></Field>
      <Field label="Board work & contrastive examples" hint="Include form, meaning, and a concise check for understanding."><textarea className="field min-h-32" value={phase.examples} onChange={(e) => onChange({ ...data, study: { ...phase, examples: e.target.value } })} placeholder="I go → she goes\nAsk: Does this describe now or a routine? How do you know?" /></Field>
      <PhaseFields value={phase} onChange={(value) => onChange({ ...data, study: { ...phase, ...value } })} activityLabel="Responsive teaching sequence" activityPlaceholder="Board three genuine examples from Activate 1. Students compare, notice the pattern, and repair their own sentences." />
      {goTo && <button className="btn-primary" onClick={() => goTo("activate2")}>Continue to Activate 2 <ArrowRight className="h-4 w-4" /></button>}
    </div>
  );
}

export function Activate2Editor({ data, onChange, goTo }: EditorProps) {
  const phase = data.activate2;
  return (
    <div className="space-y-7">
      <div className="flex gap-3 border-y bg-secondary/45 px-4 py-3 text-sm"><ArrowRight className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><p><strong>Send the learning back into play.</strong> Use a parallel task or evolve the original situation. Success now means communicating with the new tools.</p></div>
      <PhaseFields value={phase} onChange={(value) => onChange({ ...data, activate2: { ...phase, ...value } })} activityLabel="New or evolved communicative task" activityPlaceholder="Repeat the career fair with new roles and an unexpected condition. Students must negotiate a revised agreement." />
      <Field label="New constraint or twist"><textarea className="field min-h-24" value={phase.newConstraints} onChange={(e) => onChange({ ...data, activate2: { ...phase, newConstraints: e.target.value } })} placeholder="The salary is lower than expected, but the employer offers flexible hours. Reach a new agreement." /></Field>
      <Field label="Evidence of fluency & success" hint="What will you notice or record this time?"><textarea className="field min-h-24" value={phase.evidence} onChange={(e) => onChange({ ...data, activate2: { ...phase, evidence: e.target.value } })} placeholder="Students complete the negotiation, use at least two target forms without prompting, and repair breakdowns independently." /></Field>
      {goTo && <button className="btn-primary" onClick={() => goTo("report")}>Review transformation report <ArrowRight className="h-4 w-4" /></button>}
    </div>
  );
}

export function ReflectionEditor({ data, onChange, goTo }: EditorProps) {
  const reflection = data.reflection;
  return (
    <div className="space-y-7">
      <div className="flex gap-3 border-y bg-secondary/45 px-4 py-3 text-sm"><AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-primary" /><p>Reflect on your own teaching behavior as honestly as you reflect on student language.</p></div>
      <fieldset><legend className="text-sm font-bold">How difficult was it to stay silent during Activate 1?</legend><div className="mt-3 grid grid-cols-5 gap-2">{[1, 2, 3, 4, 5].map((value) => <button type="button" key={value} onClick={() => onChange({ ...data, reflection: { ...reflection, silenceDifficulty: value } })} className={`min-h-12 rounded-lg border text-sm font-bold transition-colors ${reflection.silenceDifficulty === value ? "border-primary bg-primary text-white" : "bg-white hover:border-primary"}`} aria-pressed={reflection.silenceDifficulty === value}>{value}<span className="sr-only">{value === 1 ? " — easy" : value === 5 ? " — very difficult" : ""}</span></button>)}</div><div className="mt-1 flex justify-between text-xs text-muted-foreground"><span>Easy to monitor</span><span>Very difficult</span></div></fieldset>
      <Field label="Your internal experience" hint="What tempted you to intervene? What did you notice when you did not?"><textarea className="field min-h-36" value={reflection.silenceExperience} onChange={(e) => onChange({ ...data, reflection: { ...reflection, silenceExperience: e.target.value } })} placeholder="At first I wanted to correct… I noticed that students…" /></Field>
      <Field label="What changed when Study answered their needs?" hint="Describe engagement, attention, participation, or questions students asked."><textarea className="field min-h-36" value={reflection.engagementShift} onChange={(e) => onChange({ ...data, reflection: { ...reflection, engagementShift: e.target.value } })} placeholder="Once students recognized their own language on the board…" /></Field>
      <Field label="What will you do differently next time?"><textarea className="field min-h-28" value={reflection.nextTime} onChange={(e) => onChange({ ...data, reflection: { ...reflection, nextTime: e.target.value } })} placeholder="Next time I will…" /></Field>
      {goTo && <button className="btn-primary" onClick={() => goTo("report")}>Build my report <ArrowRight className="h-4 w-4" /></button>}
    </div>
  );
}
