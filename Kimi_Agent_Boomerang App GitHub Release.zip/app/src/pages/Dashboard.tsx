import { Brand } from "@/components/Brand";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";
import { formatLessonDate, lessonProgress, statusLabel, totalMinutes } from "@/lib/lesson-utils";
import { trpc } from "@/providers/trpc";
import type { LessonRecord } from "@/types/lesson";
import { phaseMeta } from "@contracts/lesson";
import { ArrowRight, BookOpen, ChevronRight, Copy, MoreHorizontal, Plus, Search, Trash2 } from "lucide-react";
import { type FormEvent, useMemo, useState } from "react";
import { useNavigate } from "react-router";

const blankForm = { title: "", course: "", topic: "", level: "", classDate: "", studentCount: "" };

export default function Dashboard() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const lessonsQuery = trpc.lessons.list.useQuery();
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState(blankForm);
  const [formError, setFormError] = useState("");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [deleteTarget, setDeleteTarget] = useState<LessonRecord | null>(null);

  const createLesson = trpc.lessons.create.useMutation({
    onSuccess: async (lesson) => {
      await utils.lessons.list.invalidate();
      setCreateOpen(false);
      setForm(blankForm);
      navigate(`/lessons/${lesson.id}`);
    },
    onError: (error) => setFormError(error.message),
  });
  const duplicateLesson = trpc.lessons.duplicate.useMutation({ onSuccess: () => utils.lessons.list.invalidate() });
  const deleteLesson = trpc.lessons.remove.useMutation({
    onSuccess: () => { setDeleteTarget(null); utils.lessons.list.invalidate(); },
  });

  const lessons = useMemo(() => lessonsQuery.data ?? [], [lessonsQuery.data]);
  const filtered = lessons.filter((lesson) => {
    const matchesText = `${lesson.title} ${lesson.course} ${lesson.topic}`.toLowerCase().includes(query.toLowerCase());
    return matchesText && (filter === "all" || lesson.status === filter);
  });
  const gapCount = lessons.reduce((sum, lesson) => sum + lesson.data.gaps.length, 0);
  const completed = lessons.filter((lesson) => lesson.status === "completed").length;

  function submit(event: FormEvent) {
    event.preventDefault();
    setFormError("");
    if (!form.title.trim() || !form.topic.trim()) {
      setFormError("Add a lesson title and the language topic to continue.");
      return;
    }
    createLesson.mutate(form);
  }

  return (
    <div className="mx-auto max-w-[1440px] px-5 pb-16 pt-7 sm:px-8 lg:px-10 lg:pt-10">
      <section className="paper-grid relative overflow-hidden border-b pb-8">
        <div className="relative z-10 flex flex-col gap-7 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="section-label mb-3">Your teaching laboratory</p>
            <h1 className="display-type text-[2.15rem] font-extrabold leading-[1.1] sm:text-5xl">Lessons that come<br className="hidden sm:block" /> back stronger.</h1>
            <p className="mt-4 max-w-xl text-[16px] leading-relaxed text-muted-foreground">Design for communication first. Capture what students actually need, then send them back into the task better equipped.</p>
          </div>
          <button className="btn-primary chamfer w-full px-6 md:w-auto" onClick={() => setCreateOpen(true)}><Plus className="h-4 w-4" /> New Boomerang lesson</button>
        </div>
      </section>

      <section className="grid grid-cols-3 divide-x border-b py-5" aria-label="Lesson summary">
        <div className="pr-3"><span className="display-type text-2xl font-bold sm:text-3xl">{lessons.length}</span><span className="ml-2 text-xs text-muted-foreground sm:text-sm">lessons</span></div>
        <div className="px-3 sm:px-6"><span className="display-type text-2xl font-bold sm:text-3xl">{gapCount}</span><span className="ml-2 text-xs text-muted-foreground sm:text-sm">gaps found</span></div>
        <div className="pl-3 sm:pl-6"><span className="display-type text-2xl font-bold sm:text-3xl">{completed}</span><span className="ml-2 text-xs text-muted-foreground sm:text-sm">completed</span></div>
      </section>

      <section className="border-b py-7">
        <div className="mb-5 flex items-center justify-between gap-4">
          <div><h2 className="display-type text-lg font-bold">The Boomerang arc</h2><p className="mt-1 text-sm text-muted-foreground">Teach in response to the attempt, not before it.</p></div>
          <button onClick={() => navigate("/resources")} className="hidden min-h-11 items-center gap-1.5 text-sm font-semibold text-primary hover:underline sm:flex">Explore the method <ArrowRight className="h-4 w-4" /></button>
        </div>
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
          {(Object.keys(phaseMeta) as Array<keyof typeof phaseMeta>).map((key, index) => (
            <div key={key} className="relative flex items-center gap-3 bg-white px-4 py-3.5">
              <span className={`display-type flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-extrabold ${key === "activate1" ? "bg-primary text-white" : "bg-secondary text-secondary-foreground"}`}>{phaseMeta[key].short}</span>
              <span><span className="block text-sm font-bold">{phaseMeta[key].title}</span><span className="block text-xs text-muted-foreground">{phaseMeta[key].subtitle}</span></span>
              {index < 3 && <ChevronRight className="ml-auto hidden h-4 w-4 text-muted-foreground xl:block" />}
            </div>
          ))}
        </div>
      </section>

      <section className="pt-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="display-type text-2xl font-bold">Lesson library</h2>
          <div className="flex flex-col gap-2 sm:flex-row">
            <label className="relative"><span className="sr-only">Search lessons</span><Search className="pointer-events-none absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" /><input value={query} onChange={(e) => setQuery(e.target.value)} className="field min-h-11 pl-9 sm:w-56" placeholder="Search lessons" /></label>
            <select className="field min-h-11 sm:w-40" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter lessons by status"><option value="all">All statuses</option><option value="draft">Draft</option><option value="ready">Ready to teach</option><option value="completed">Completed</option></select>
          </div>
        </div>

        {lessonsQuery.isLoading ? (
          <div className="mt-7 space-y-3" role="status">{[1, 2, 3].map((item) => <div key={item} className="h-28 animate-pulse rounded-lg bg-muted" />)}<span className="sr-only">Loading lessons</span></div>
        ) : lessonsQuery.isError ? (
          <div className="mt-7 border p-6"><p className="font-semibold">We couldn’t load your lessons.</p><p className="mt-1 text-sm text-muted-foreground">Check your connection and try again.</p><button className="btn-secondary mt-4" onClick={() => lessonsQuery.refetch()}>Try again</button></div>
        ) : lessons.length === 0 ? (
          <div className="mt-7 grid gap-8 border-y py-10 md:grid-cols-[1fr_auto] md:items-center">
            <div className="max-w-lg"><BookOpen className="h-7 w-7 text-primary" /><h3 className="display-type mt-4 text-xl font-bold">Your first lesson starts with a problem.</h3><p className="mt-2 text-muted-foreground">Choose a grammar-heavy topic, then design the communicative situation that will make students need it.</p><button className="btn-primary mt-5" onClick={() => setCreateOpen(true)}><Plus className="h-4 w-4" /> Plan your first lesson</button></div>
            <div className="hidden pr-10 md:block"><Brand compact className="scale-[2.5]" /></div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-7 border-y py-10 text-center"><p className="font-semibold">No lessons match this view.</p><button className="mt-3 min-h-11 text-sm font-semibold text-primary hover:underline" onClick={() => { setQuery(""); setFilter("all"); }}>Clear filters</button></div>
        ) : (
          <div className="mt-6 divide-y border-y">
            {filtered.map((lesson) => {
              const progress = lessonProgress(lesson.data);
              return (
                <article key={lesson.id} className="group relative grid gap-4 py-5 transition-colors hover:bg-white sm:px-4 md:grid-cols-[minmax(0,1fr)_150px_120px_44px] md:items-center">
                  <button className="min-w-0 text-left" onClick={() => navigate(`/lessons/${lesson.id}`)}>
                    <div className="flex flex-wrap items-center gap-2"><h3 className="display-type truncate text-lg font-bold group-hover:text-primary">{lesson.title}</h3><span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${lesson.status === "completed" ? "bg-green-100 text-green-800" : lesson.status === "ready" ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}`}>{statusLabel(lesson.status)}</span></div>
                    <p className="mt-1.5 truncate text-sm text-muted-foreground">{lesson.topic}{lesson.course ? ` · ${lesson.course}` : ""}{lesson.level ? ` · ${lesson.level}` : ""}</p>
                    <div className="mt-3 flex items-center gap-3"><Progress value={progress} className="h-1.5 w-28" /><span className="text-xs font-medium text-muted-foreground">{progress}% planned</span></div>
                  </button>
                  <div className="text-sm"><span className="block font-semibold">{totalMinutes(lesson.data)} minutes</span><span className="text-xs text-muted-foreground">{formatLessonDate(lesson.classDate)}</span></div>
                  <div className="text-sm"><span className="block font-semibold">{lesson.data.gaps.length} gaps</span><span className="text-xs text-muted-foreground">{lesson.data.gaps.filter((gap) => gap.selected).length} used in Study</span></div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild><button className="icon-button" aria-label={`Actions for ${lesson.title}`}><MoreHorizontal className="h-5 w-5" /></button></DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuItem className="min-h-11 cursor-pointer" onClick={() => duplicateLesson.mutate({ id: lesson.id })}><Copy className="mr-2 h-4 w-4" /> Duplicate</DropdownMenuItem>
                      <DropdownMenuItem className="min-h-11 cursor-pointer text-destructive focus:text-destructive" onClick={() => setDeleteTarget(lesson)}><Trash2 className="mr-2 h-4 w-4" /> Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </article>
              );
            })}
          </div>
        )}
      </section>

      <Dialog open={createOpen} onOpenChange={(open) => { setCreateOpen(open); if (!open) setFormError(""); }}>
        <DialogContent className="max-h-[92dvh] overflow-y-auto sm:max-w-xl">
          <DialogHeader><DialogTitle className="display-type text-2xl">Start a Boomerang lesson</DialogTitle><DialogDescription>Set the teaching context now. The exact Study focus will emerge from your students’ first attempt.</DialogDescription></DialogHeader>
          <form onSubmit={submit} className="space-y-4">
            <label className="block text-sm font-semibold">Lesson title<input autoFocus className="field mt-1.5" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. The unexpected career fair" /></label>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block text-sm font-semibold">Language topic<input className="field mt-1.5" value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} placeholder="e.g. Present simple for routines" /></label>
              <label className="block text-sm font-semibold">Course<input className="field mt-1.5" value={form.course} onChange={(e) => setForm({ ...form, course: e.target.value })} placeholder="e.g. English for Engineering" /></label>
              <label className="block text-sm font-semibold">Student level<input className="field mt-1.5" value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })} placeholder="e.g. B1 university" /></label>
              <label className="block text-sm font-semibold">Class size<input className="field mt-1.5" inputMode="numeric" value={form.studentCount} onChange={(e) => setForm({ ...form, studentCount: e.target.value })} placeholder="e.g. 24" /></label>
            </div>
            <label className="block text-sm font-semibold">Teaching date<input type="date" className="field mt-1.5" value={form.classDate} onChange={(e) => setForm({ ...form, classDate: e.target.value })} /></label>
            {formError && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{formError}</p>}
            <DialogFooter><button type="button" className="btn-secondary" onClick={() => setCreateOpen(false)}>Cancel</button><button type="submit" className="btn-primary" disabled={createLesson.isPending}>{createLesson.isPending ? "Creating…" : "Create & start planning"}<ArrowRight className="h-4 w-4" /></button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete “{deleteTarget?.title}”?</AlertDialogTitle><AlertDialogDescription>This permanently removes the plan, gap notes, and reflection. This action cannot be undone.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel className="min-h-11">Keep lesson</AlertDialogCancel><AlertDialogAction className="min-h-11 bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteTarget && deleteLesson.mutate({ id: deleteTarget.id })}>{deleteLesson.isPending ? "Deleting…" : "Delete lesson"}</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
