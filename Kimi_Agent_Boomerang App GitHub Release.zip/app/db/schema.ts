import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  json,
  index,
} from "drizzle-orm/mysql-core";
import type { LessonData } from "@contracts/lesson";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: text("passwordHash").notNull(),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export const lessons = mysqlTable(
  "lessons",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    course: varchar("course", { length: 180 }).notNull().default(""),
    topic: varchar("topic", { length: 180 }).notNull(),
    level: varchar("level", { length: 80 }).notNull().default(""),
    classDate: varchar("classDate", { length: 30 }).notNull().default(""),
    studentCount: varchar("studentCount", { length: 20 }).notNull().default(""),
    status: mysqlEnum("status", ["draft", "ready", "completed"]).default("draft").notNull(),
    data: json("data").$type<LessonData>().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    userUpdatedIdx: index("lessons_user_updated_idx").on(table.userId, table.updatedAt),
  }),
);

export type User = typeof users.$inferSelect;
export type PublicUser = Omit<User, "passwordHash">;
export type InsertUser = typeof users.$inferInsert;
export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = typeof lessons.$inferInsert;
