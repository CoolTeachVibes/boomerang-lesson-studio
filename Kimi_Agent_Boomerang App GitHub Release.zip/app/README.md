# Boomerang Lesson Studio

A self-hosted, full-stack planning workspace for university professors using the Boomerang ESA framework. It supports the complete Disruptive English Teaching workflow: plan the lesson, observe the first communicative attempt, teach to real language gaps, repeat the task, and produce a Transformation Report.

## Features

- Guided **Engage → Activate 1 → Study → Activate 2** lesson editor
- Activate 1 monitoring mode with timer and exact-language observations
- Selected gap links that shape the Study phase
- Rebel Reflection and eight-point submission readiness checklist
- Two-page A4 report through **Print / Save PDF**, plus Markdown export
- Method library, Jobs transformation case study, and reference video
- Email/password accounts with private, user-scoped lessons
- Responsive desktop and mobile layouts
- MySQL persistence, Drizzle migrations, Docker Compose, and GitHub Actions

## Technology

React 19 · TypeScript · Vite · Tailwind CSS · Hono · tRPC · Drizzle ORM · MySQL 8 · JOSE sessions · Node.js 20

The browser and API are served from the same Node.js process in production. No platform-specific OAuth, database, or hosting service is required.

## Quick start with Docker

Prerequisites: Docker with Compose v2.

```bash
git clone <your-repository-url>
cd boomerang-lesson-studio
cp .env.example .env
# Generate a strong session secret:
openssl rand -hex 32
```

Set `APP_SECRET` in `.env` to the generated value. For anything beyond local evaluation, also set unique `MYSQL_PASSWORD` and `MYSQL_ROOT_PASSWORD` values.

```bash
docker compose up --build
```

Open **http://localhost:3000**, create an account, and start planning. The application waits for MySQL, applies committed migrations, and exposes a health check at `/api/health`.

Stop the app with `docker compose down`. Lesson data persists in the `boomerang_mysql` volume. To back up the database before upgrades, use your standard MySQL dump process.

## Local development

Prerequisites: Node.js 20+ and a MySQL 8+ database.

```bash
npm ci
cp .env.example .env
```

Configure `DATABASE_URL` and `APP_SECRET` in `.env`, then run:

```bash
npm run db:migrate
npm run dev
```

Vite serves the app and API at **http://localhost:3000** with hot reload.

### Useful commands

| Command | Purpose |
| --- | --- |
| `npm run dev` | Development server |
| `npm run check` | TypeScript validation |
| `npm run test` | Unit tests |
| `npm run build` | Production browser bundle and bundled Node server |
| `npm start` | Production server |
| `npm run db:generate` | Generate a migration after schema changes |
| `npm run db:migrate` | Apply committed migrations |
| `npm run db:push` | Development-only schema synchronization |

## Publish this repository on GitHub

```bash
git init
git add .
git commit -m "Initial Boomerang Lesson Studio release"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/boomerang-lesson-studio.git
git push -u origin main
```

If the downloaded project already contains Git history, review `git remote -v` and `git status` before adding your own remote. **Never commit `.env` or real database credentials.** The supplied `.gitignore` excludes them.

## Manual production deployment

Use Node.js 20, MySQL 8+, and HTTPS. Build and run on the same architecture:

```bash
npm ci
npm run db:migrate
npm run build
NODE_ENV=production npm start
```

Required environment variables:

| Variable | Description |
| --- | --- |
| `DATABASE_URL` | MySQL connection string |
| `APP_SECRET` | Random session-signing secret, at least 32 characters |
| `PORT` | HTTP port; defaults to `3000` |
| `AUTO_MIGRATE` | Set `true` to apply migrations at production startup |

Keep `AUTO_MIGRATE=false` for manual migration workflows. When enabled, the runtime expects `db/migrations` beside the application working directory; the supplied Dockerfile includes it.

For production, place the Node process behind an HTTPS reverse proxy and run it with a process supervisor or container orchestrator. Session cookies are HTTP-only, SameSite=Lax, and Secure outside localhost. Use a strong unique `APP_SECRET`; rotating it signs out all users.

## Project structure

```text
api/                 Hono server, tRPC routers, sessions, password hashing
contracts/           Shared validation schemas and constants
db/                  Drizzle schema and committed SQL migrations
src/                 React application and lesson-planning interface
.github/workflows/   Continuous integration
Dockerfile           Production image with migration files
docker-compose.yml   App + MySQL services
```

## Verification

The repository checks TypeScript, unit-tests password hashing and Boomerang readiness rules, builds production assets, and validates the Docker image in GitHub Actions. Before a release, also test registration, sign-in, lesson persistence, and report printing against your target database.

## Security notes

Passwords use Node.js `scrypt` with a unique random salt. Authentication responses never include password hashes. Login and registration have basic in-process throttling; for a large public deployment, add proxy-level rate limiting, email verification/password recovery, and centralized monitoring. See [SECURITY.md](SECURITY.md).

## License

MIT — see [LICENSE](LICENSE).
