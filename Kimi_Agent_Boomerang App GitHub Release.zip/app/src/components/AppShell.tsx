import { useAuth } from "@/hooks/useAuth";
import { BookOpen, LayoutGrid, LogOut, Menu, RotateCcw, X } from "lucide-react";
import { useState } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router";
import { Brand } from "./Brand";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";

const navItems = [
  { label: "My lessons", path: "/", icon: LayoutGrid },
  { label: "Method library", path: "/resources", icon: BookOpen },
];

export default function AppShell() {
  const { user, isLoading, logout } = useAuth({ redirectOnUnauthenticated: true });
  const location = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-background" role="status">
        <div className="flex flex-col items-center gap-4">
          <Brand />
          <div className="h-1.5 w-36 overflow-hidden rounded-full bg-secondary">
            <div className="h-full w-1/2 animate-pulse rounded-full bg-primary" />
          </div>
          <span className="text-sm text-muted-foreground">Opening your workspace…</span>
        </div>
      </div>
    );
  }
  if (!user) return null;

  const profile = (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex min-h-12 w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition-colors hover:bg-muted" aria-label="Open account menu">
          <Avatar className="h-9 w-9 border bg-white">
            <AvatarFallback className="bg-accent text-xs font-bold text-accent-foreground">{user.name?.charAt(0).toUpperCase() || "P"}</AvatarFallback>
          </Avatar>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-semibold">{user.name || "Professor"}</span>
            <span className="block truncate text-xs text-muted-foreground">{user.email || "University educator"}</span>
          </span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52">
        <DropdownMenuItem onClick={logout} className="min-h-11 cursor-pointer text-destructive focus:text-destructive">
          <LogOut className="mr-2 h-4 w-4" /> Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[248px_minmax(0,1fr)]">
      <aside className="sticky top-0 hidden h-dvh flex-col border-r bg-[hsl(var(--sidebar-background))] px-4 py-5 lg:flex">
        <Link to="/" className="flex min-h-11 items-center px-2" aria-label="Boomerang Lesson Studio home"><Brand /></Link>
        <div className="mt-10 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Disruptive English Teaching</div>
        <nav className="mt-3 space-y-1" aria-label="Main navigation">
          {navItems.map((item) => {
            const active = item.path === "/" ? location.pathname === "/" || location.pathname.startsWith("/lessons") : location.pathname.startsWith(item.path);
            return (
              <Link key={item.path} to={item.path} className={`flex min-h-12 items-center gap-3 rounded-lg px-3 text-sm font-semibold transition-colors ${active ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}>
                <item.icon className="h-[18px] w-[18px]" /> {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto">
          <div className="mx-1 mb-5 border-t pt-5">
            <RotateCcw className="h-5 w-5 text-primary" />
            <p className="mt-3 text-sm font-semibold">Communication first.<br />Correction when it counts.</p>
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">Let the first attempt reveal the lesson.</p>
          </div>
          {profile}
        </div>
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b bg-background/95 px-4 backdrop-blur lg:hidden">
          <Link to="/" aria-label="Home"><Brand /></Link>
          <button className="icon-button" onClick={() => setMenuOpen((open) => !open)} aria-expanded={menuOpen} aria-label={menuOpen ? "Close menu" : "Open menu"}>
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </header>
        {menuOpen && (
          <div className="fixed inset-x-0 top-16 z-40 border-b bg-background p-4 shadow-lg lg:hidden">
            <nav className="space-y-1">
              {navItems.map((item) => (
                <button key={item.path} onClick={() => { navigate(item.path); setMenuOpen(false); }} className="flex min-h-12 w-full items-center gap-3 rounded-lg px-3 text-left font-semibold hover:bg-muted">
                  <item.icon className="h-5 w-5" />{item.label}
                </button>
              ))}
            </nav>
            <div className="mt-3 border-t pt-3">{profile}</div>
          </div>
        )}
        <main className="min-h-[calc(100dvh-4rem)] lg:min-h-dvh"><Outlet /></main>
      </div>
    </div>
  );
}
