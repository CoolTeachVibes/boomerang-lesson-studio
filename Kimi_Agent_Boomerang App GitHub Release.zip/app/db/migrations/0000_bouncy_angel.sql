CREATE TABLE `lessons` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`title` varchar(180) NOT NULL,
	`course` varchar(180) NOT NULL DEFAULT '',
	`topic` varchar(180) NOT NULL,
	`level` varchar(80) NOT NULL DEFAULT '',
	`classDate` varchar(30) NOT NULL DEFAULT '',
	`studentCount` varchar(20) NOT NULL DEFAULT '',
	`status` enum('draft','ready','completed') NOT NULL DEFAULT 'draft',
	`data` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lessons_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` text NOT NULL,
	`avatar` text,
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	`lastSignInAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE INDEX `lessons_user_updated_idx` ON `lessons` (`userId`,`updatedAt`);