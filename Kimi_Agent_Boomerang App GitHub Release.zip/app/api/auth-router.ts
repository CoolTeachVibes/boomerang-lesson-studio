import * as cookie from "cookie";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { Session } from "@contracts/constants";
import type { PublicUser, User } from "@db/schema";
import { getSessionCookieOptions } from "./lib/cookies";
import { createRouter, publicQuery } from "./middleware";
import { hashPassword, verifyPassword } from "./auth/password";
import { authenticateRequest, createSessionToken } from "./auth/session";
import { createUser, findUserByEmail, touchSignIn } from "./queries/users";

const emailSchema = z.string().trim().min(3).max(320).email().transform((email) => email.toLowerCase());
const passwordSchema = z.string().min(12, "Use at least 12 characters").max(128);
const attempts = new Map<string, { count: number; resetAt: number }>();

function publicUser(user: User): PublicUser {
  const { passwordHash: _passwordHash, ...safeUser } = user;
  return safeUser;
}

function checkRateLimit(key: string) {
  const now = Date.now();
  const current = attempts.get(key);
  if (current && current.resetAt > now && current.count >= 8) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Try again in 15 minutes." });
  }
  if (!current || current.resetAt <= now) attempts.set(key, { count: 0, resetAt: now + 15 * 60 * 1000 });
}

function recordFailure(key: string) {
  const current = attempts.get(key);
  if (current) current.count += 1;
}

function setSession(ctx: { req: Request; resHeaders: Headers }, token: string) {
  const options = getSessionCookieOptions(ctx.req.headers);
  ctx.resHeaders.append(
    "set-cookie",
    cookie.serialize(Session.cookieName, token, {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      secure: options.secure,
      maxAge: Session.maxAgeMs / 1000,
    }),
  );
}

export const authRouter = createRouter({
  me: publicQuery.query(async ({ ctx }) => {
    const user = ctx.user ?? (await authenticateRequest(ctx.req.headers));
    return user ? publicUser(user) : null;
  }),

  register: publicQuery
    .input(z.object({ name: z.string().trim().min(2).max(100), email: emailSchema, password: passwordSchema }))
    .mutation(async ({ ctx, input }) => {
      checkRateLimit(`register:${input.email}`);
      if (await findUserByEmail(input.email)) {
        throw new TRPCError({ code: "CONFLICT", message: "An account already exists for this email." });
      }
      const user = await createUser({
        name: input.name,
        email: input.email,
        passwordHash: await hashPassword(input.password),
        lastSignInAt: new Date(),
      });
      setSession(ctx, await createSessionToken(user.id));
      return publicUser(user);
    }),

  login: publicQuery
    .input(z.object({ email: emailSchema, password: z.string().min(1).max(128) }))
    .mutation(async ({ ctx, input }) => {
      checkRateLimit(`login:${input.email}`);
      const user = await findUserByEmail(input.email);
      if (!user || !(await verifyPassword(input.password, user.passwordHash))) {
        recordFailure(`login:${input.email}`);
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Email or password is incorrect." });
      }
      attempts.delete(`login:${input.email}`);
      await touchSignIn(user.id);
      setSession(ctx, await createSessionToken(user.id));
      return publicUser(user);
    }),

  logout: publicQuery.mutation(async ({ ctx }) => {
    const options = getSessionCookieOptions(ctx.req.headers);
    ctx.resHeaders.append(
      "set-cookie",
      cookie.serialize(Session.cookieName, "", {
        httpOnly: true,
        path: "/",
        sameSite: "lax",
        secure: options.secure,
        maxAge: 0,
      }),
    );
    return { success: true };
  }),
});
