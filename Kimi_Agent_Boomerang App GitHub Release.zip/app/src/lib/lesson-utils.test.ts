import { describe, expect, it } from "vitest";
import { emptyLessonData } from "@contracts/lesson";
import { lessonProgress, readinessChecks, totalMinutes } from "./lesson-utils";

describe("Boomerang lesson readiness", () => {
  it("starts with an incomplete plan and the default teaching time", () => {
    const data = emptyLessonData();
    expect(totalMinutes(data)).toBe(50);
    expect(lessonProgress(data)).toBe(0);
    expect(readinessChecks(data).every((check) => !check.complete)).toBe(true);
  });

  it("requires Study to respond to a selected observation", () => {
    const data = emptyLessonData();
    data.study.focus = "Third-person singular";
    data.study.instructions = "Notice and repair";
    data.study.examples = "I go / she goes";
    data.gaps.push({ id: "gap-1", type: "grammar", observation: "He go", neededLanguage: "He goes", selected: false });
    expect(readinessChecks(data).find((check) => check.id === "study-link")?.complete).toBe(false);
    data.gaps[0].selected = true;
    expect(readinessChecks(data).find((check) => check.id === "study-link")?.complete).toBe(true);
  });
});
