import { z } from "zod";

export const phaseKeys = ["engage", "activate1", "study", "activate2"] as const;
export type PhaseKey = (typeof phaseKeys)[number];

export const gapTypes = ["vocabulary", "grammar", "pronunciation", "discourse"] as const;
export type GapType = (typeof gapTypes)[number];

export const phaseSchema = z.object({
  activity: z.string().max(5000),
  instructions: z.string().max(5000),
  materials: z.string().max(2000),
  minutes: z.number().int().min(1).max(180),
});

export const gapSchema = z.object({
  id: z.string(),
  type: z.enum(gapTypes),
  observation: z.string().max(2000),
  neededLanguage: z.string().max(2000),
  selected: z.boolean(),
});

export const lessonDataSchema = z.object({
  engage: phaseSchema,
  activate1: phaseSchema.extend({
    taskType: z.string().max(120),
    successCriteria: z.string().max(3000),
  }),
  study: phaseSchema.extend({
    focus: z.string().max(5000),
    examples: z.string().max(5000),
  }),
  activate2: phaseSchema.extend({
    newConstraints: z.string().max(3000),
    evidence: z.string().max(3000),
  }),
  gaps: z.array(gapSchema).max(100),
  reflection: z.object({
    silenceDifficulty: z.number().int().min(1).max(5),
    silenceExperience: z.string().max(5000),
    engagementShift: z.string().max(5000),
    nextTime: z.string().max(5000),
  }),
});

export type LessonData = z.infer<typeof lessonDataSchema>;
export type PhaseData = z.infer<typeof phaseSchema>;
export type GapNote = z.infer<typeof gapSchema>;
export type LessonStatus = "draft" | "ready" | "completed";

export const emptyLessonData = (): LessonData => ({
  engage: { activity: "", instructions: "", materials: "", minutes: 5 },
  activate1: {
    activity: "",
    instructions: "",
    materials: "",
    minutes: 15,
    taskType: "Role-play",
    successCriteria: "",
  },
  study: { activity: "", instructions: "", materials: "", minutes: 15, focus: "", examples: "" },
  activate2: {
    activity: "",
    instructions: "",
    materials: "",
    minutes: 15,
    newConstraints: "",
    evidence: "",
  },
  gaps: [],
  reflection: { silenceDifficulty: 3, silenceExperience: "", engagementShift: "", nextTime: "" },
});

export const phaseMeta: Record<PhaseKey, { short: string; title: string; subtitle: string }> = {
  engage: { short: "E", title: "Engage", subtitle: "Spark curiosity" },
  activate1: { short: "A1", title: "Activate 1", subtitle: "Identify the gap" },
  study: { short: "S", title: "Study", subtitle: "Teach to the need" },
  activate2: { short: "A2", title: "Activate 2", subtitle: "Return to communication" },
};
