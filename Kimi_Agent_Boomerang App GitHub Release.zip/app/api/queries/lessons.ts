import { and, desc, eq } from "drizzle-orm";
import { lessons, type InsertLesson } from "@db/schema";
import { getDb } from "./connection";

export async function findLessonsByUser(userId: number) {
  return getDb()
    .select()
    .from(lessons)
    .where(eq(lessons.userId, userId))
    .orderBy(desc(lessons.updatedAt));
}

export async function findLessonById(id: number, userId: number) {
  const [lesson] = await getDb()
    .select()
    .from(lessons)
    .where(and(eq(lessons.id, id), eq(lessons.userId, userId)))
    .limit(1);
  return lesson ?? null;
}

export async function createLesson(data: InsertLesson) {
  const [{ id }] = await getDb().insert(lessons).values(data).$returningId();
  return findLessonById(id, data.userId);
}

export async function updateLesson(id: number, userId: number, data: Partial<InsertLesson>) {
  await getDb()
    .update(lessons)
    .set(data)
    .where(and(eq(lessons.id, id), eq(lessons.userId, userId)));
  return findLessonById(id, userId);
}

export async function deleteLesson(id: number, userId: number) {
  const result = await getDb()
    .delete(lessons)
    .where(and(eq(lessons.id, id), eq(lessons.userId, userId)));
  return Number(result[0].affectedRows ?? 0) > 0;
}
