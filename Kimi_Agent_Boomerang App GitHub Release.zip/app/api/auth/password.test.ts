import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./password";

describe("password hashing", () => {
  it("verifies the correct password without storing plaintext", async () => {
    const hash = await hashPassword("a-secure-passphrase");
    expect(hash).toMatch(/^scrypt:[a-f0-9]{32}:[a-f0-9]{128}$/);
    expect(hash).not.toContain("a-secure-passphrase");
    expect(await verifyPassword("a-secure-passphrase", hash)).toBe(true);
  });

  it("rejects an incorrect password and malformed hashes", async () => {
    const hash = await hashPassword("a-secure-passphrase");
    expect(await verifyPassword("the-wrong-passphrase", hash)).toBe(false);
    expect(await verifyPassword("anything", "plain-text")).toBe(false);
  });

  it("uses a unique salt for each password", async () => {
    const first = await hashPassword("same-passphrase");
    const second = await hashPassword("same-passphrase");
    expect(first).not.toEqual(second);
  });
});
