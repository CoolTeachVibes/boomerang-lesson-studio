import type { PhaseData } from "@contracts/lesson";
import type { ReactNode } from "react";

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="block text-sm font-bold">{label}</span>
      {hint && <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">{hint}</span>}
      <span className="mt-2 block">{children}</span>
    </label>
  );
}

export function PhaseFields({ value, onChange, activityLabel = "Activity", activityPlaceholder }: {
  value: PhaseData;
  onChange: (value: PhaseData) => void;
  activityLabel?: string;
  activityPlaceholder?: string;
}) {
  return (
    <div className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-[minmax(0,1fr)_112px]">
        <Field label={activityLabel}><textarea className="field min-h-24 resize-y" value={value.activity} onChange={(e) => onChange({ ...value, activity: e.target.value })} placeholder={activityPlaceholder} /></Field>
        <Field label="Minutes"><input type="number" min={1} max={180} className="field" value={value.minutes} onChange={(e) => onChange({ ...value, minutes: Math.max(1, Math.min(180, Number(e.target.value) || 1)) })} /></Field>
      </div>
      <Field label="Student instructions" hint="Write what students will actually do, in language you could use in class."><textarea className="field min-h-28 resize-y" value={value.instructions} onChange={(e) => onChange({ ...value, instructions: e.target.value })} placeholder="Work in pairs. You have… Your goal is…" /></Field>
      <Field label="Materials & setup"><textarea className="field min-h-20 resize-y" value={value.materials} onChange={(e) => onChange({ ...value, materials: e.target.value })} placeholder="One image, role cards, groups of three…" /></Field>
    </div>
  );
}
