import "dotenv/config";

function required(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}. Copy .env.example to .env and configure it.`);
  }
  return value;
}

const isProduction = process.env.NODE_ENV === "production";
const appSecret = required("APP_SECRET");
if (isProduction && appSecret.length < 32) {
  throw new Error("APP_SECRET must contain at least 32 characters in production.");
}

export const env = {
  appSecret,
  isProduction,
  databaseUrl: required("DATABASE_URL"),
  autoMigrate: process.env.AUTO_MIGRATE === "true",
};
