import { Route, Routes } from "react-router";
import AppShell from "./components/AppShell";
import Dashboard from "./pages/Dashboard";
import LessonPlanner from "./pages/LessonPlanner";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Resources from "./pages/Resources";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<AppShell />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/lessons/:id" element={<LessonPlanner />} />
        <Route path="/resources" element={<Resources />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
