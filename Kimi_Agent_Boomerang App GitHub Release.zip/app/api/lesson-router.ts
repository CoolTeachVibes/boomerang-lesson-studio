import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { emptyLessonData, lessonDataSchema } from "@contracts/lesson";
import { authedQuery, createRouter } from "./middleware";
import {
  createLesson,
  deleteLesson,
  findLessonById,
  findLessonsByUser,
  updateLesson,
} from "./queries/lessons";

const idSchema = z.object({ id: z.number().int().positive() });
const lessonFields = {
  title: z.string().trim().min(1).max(180),
  course: z.string().max(180),
  topic: z.string().trim().min(1).max(180),
  level: z.string().max(80),
  classDate: z.string().max(30),
  studentCount: z.string().max(20),
};

async function ownedLesson(id: number, userId: number) {
  const lesson = await findLessonById(id, userId);
  if (!lesson) throw new TRPCError({ code: "NOT_FOUND", message: "Lesson not found" });
  return lesson;
}

export const lessonRouter = createRouter({
  list: authedQuery.query(({ ctx }) => findLessonsByUser(ctx.user.id)),

  byId: authedQuery.input(idSchema).query(({ ctx, input }) => ownedLesson(input.id, ctx.user.id)),

  create: authedQuery.input(z.object(lessonFields)).mutation(async ({ ctx, input }) => {
    const lesson = await createLesson({ ...input, userId: ctx.user.id, data: emptyLessonData() });
    if (!lesson) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    return lesson;
  }),

  update: authedQuery
    .input(
      z.object({
        ...lessonFields,
        ...idSchema.shape,
        status: z.enum(["draft", "ready", "completed"]),
        data: lessonDataSchema,
      }),
    )
    .mutation(async ({ ctx, input }) => {
      await ownedLesson(input.id, ctx.user.id);
      const { id, ...data } = input;
      return updateLesson(id, ctx.user.id, data);
    }),

  duplicate: authedQuery.input(idSchema).mutation(async ({ ctx, input }) => {
    const source = await ownedLesson(input.id, ctx.user.id);
    const lesson = await createLesson({
      userId: ctx.user.id,
      title: `${source.title} (copy)`.slice(0, 180),
      course: source.course,
      topic: source.topic,
      level: source.level,
      classDate: source.classDate,
      studentCount: source.studentCount,
      status: "draft",
      data: structuredClone(source.data),
    });
    if (!lesson) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
    return lesson;
  }),

  remove: authedQuery.input(idSchema).mutation(async ({ ctx, input }) => {
    await ownedLesson(input.id, ctx.user.id);
    await deleteLesson(input.id, ctx.user.id);
    return { id: input.id };
  }),
});
