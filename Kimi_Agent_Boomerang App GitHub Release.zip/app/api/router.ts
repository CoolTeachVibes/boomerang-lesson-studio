import { authRouter } from "./auth-router";
import { lessonRouter } from "./lesson-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  lessons: lessonRouter,
});

export type AppRouter = typeof appRouter;
