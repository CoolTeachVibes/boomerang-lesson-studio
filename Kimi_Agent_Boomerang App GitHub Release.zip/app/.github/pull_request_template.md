## What changed

<!-- Summarize the user-facing and technical changes. -->

## Why

<!-- Link the issue or explain the teaching/workflow problem. -->

## Verification

- [ ] `npm run check`
- [ ] `npm run test`
- [ ] `npm run build`
- [ ] Tested registration/sign-in or explained why not affected
- [ ] Tested desktop and 375px mobile layouts for UI changes
- [ ] Included migrations for schema changes and considered existing data

## Screenshots

<!-- Required for visible UI changes. -->
