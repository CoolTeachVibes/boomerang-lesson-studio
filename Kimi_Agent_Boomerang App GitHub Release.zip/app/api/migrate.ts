import path from "node:path";
import { migrate } from "drizzle-orm/mysql2/migrator";
import { getDb } from "./queries/connection";
import { log } from "./lib/logger";

export async function runMigrations() {
  await migrate(getDb(), { migrationsFolder: path.resolve(process.cwd(), "db/migrations") });
  log.info("Database migrations applied");
}
