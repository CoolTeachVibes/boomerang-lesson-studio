import { Activate1Editor, Activate2Editor, EngageEditor, ReflectionEditor, StudyEditor } from "@/components/lesson/PhaseEditors";
import { ReportView } from "@/components/lesson/ReportView";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { lessonProgress, readinessChecks, statusLabel, totalMinutes } from "@/lib/lesson-utils";
import { trpc } from "@/providers/trpc";
import type { EditorSection, LessonDraft, LessonRecord } from "@/types/lesson";
import { phaseMeta, type LessonData, type PhaseKey } from "@contracts/lesson";
import { ArrowLeft, BookOpenCheck, Check, CheckCircle2, ChevronRight, Circle, Cloud, CloudOff, FileText, Loader2, Pencil, Save, Settings2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router";

const sectionInfo: Record<EditorSection, { eyebrow: string; title: string; description: string }> = {
  engage: { eyebrow: "Phase 1 · Spark curiosity", title: "Engage", description: "Create emotional involvement. Keep the rules off the stage." },
  activate1: { eyebrow: "Phase 2 · Identify the gap", title: "Activate 1", description: "Throw students into communication and discover what they need." },
  study: { eyebrow: "Phase 3 · Targeted form", title: "Study", description: "Turn observed struggles into a precise, useful teaching moment." },
  activate2: { eyebrow: "Phase 4 · Fluency & success", title: "Activate 2", description: "Return to communication with new language and a fresh reason to use it." },
  reflection: { eyebrow: "After class · Rebel reflection", title: "Notice your own instinct to correct", description: "Document what happened inside you—and among your students." },
  report: { eyebrow: "Course deliverable", title: "Transformation Report", description: "A concise, two-page account of your classroom experiment." },
};

function toDraft(lesson: LessonRecord): LessonDraft {
  return { id: lesson.id, title: lesson.title, course: lesson.course, topic: lesson.topic, level: lesson.level, classDate: lesson.classDate, studentCount: lesson.studentCount, status: lesson.status, data: lesson.data };
}

export default function LessonPlanner() {
  const { id } = useParams();
  const lessonId = Number(id);
  const navigate = useNavigate();
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const lessonQuery = trpc.lessons.byId.useQuery({ id: lessonId }, { enabled: Number.isInteger(lessonId) && lessonId > 0, retry: false });
  const [draft, setDraft] = useState<LessonDraft | null>(null);
  const [section, setSection] = useState<EditorSection>("engage");
  const [saveStatus, setSaveStatus] = useState<"saved" | "unsaved" | "saving" | "error">("saved");
  const [detailsOpen, setDetailsOpen] = useState(false);
  const loadedFor = useRef<number | null>(null);
  const editVersion = useRef(0);
  const savedVersion = useRef(0);

  const updateLesson = trpc.lessons.update.useMutation();

  useEffect(() => {
    if (lessonQuery.data && loadedFor.current !== lessonQuery.data.id) {
      loadedFor.current = lessonQuery.data.id;
      setDraft(toDraft(lessonQuery.data));
      editVersion.current = 0;
      savedVersion.current = 0;
      setSaveStatus("saved");
    }
  }, [lessonQuery.data]);

  const saveDraft = useCallback(async (value: LessonDraft) => {
    const version = editVersion.current;
    setSaveStatus("saving");
    try {
      const saved = await updateLesson.mutateAsync(value);
      utils.lessons.byId.setData({ id: value.id }, saved);
      utils.lessons.list.invalidate();
      if (editVersion.current === version) {
        savedVersion.current = version;
        setSaveStatus("saved");
      } else {
        setSaveStatus("unsaved");
      }
    } catch {
      setSaveStatus("error");
    }
  }, [updateLesson.mutateAsync, utils]);

  useEffect(() => {
    if (!draft || saveStatus !== "unsaved") return;
    const timer = window.setTimeout(() => saveDraft(draft), 650);
    return () => window.clearTimeout(timer);
  }, [draft, saveStatus, saveDraft]);

  function changeData(data: LessonData) {
    editVersion.current += 1;
    setDraft((current) => current ? { ...current, data } : current);
    setSaveStatus("unsaved");
  }

  function changeMeta(patch: Partial<Omit<LessonDraft, "data" | "id">>) {
    editVersion.current += 1;
    setDraft((current) => current ? { ...current, ...patch } : current);
    setSaveStatus("unsaved");
  }

  if (lessonQuery.isLoading || (!draft && !lessonQuery.isError)) {
    return <div className="flex min-h-[70dvh] items-center justify-center" role="status"><div className="text-center"><Loader2 className="mx-auto h-6 w-6 animate-spin text-primary" /><p className="mt-3 text-sm text-muted-foreground">Opening your lesson…</p></div></div>;
  }
  if (lessonQuery.isError || !draft) {
    return <div className="mx-auto max-w-lg px-5 py-24 text-center"><CloudOff className="mx-auto h-8 w-8 text-muted-foreground" /><h1 className="display-type mt-4 text-2xl font-bold">This lesson couldn’t be opened.</h1><p className="mt-2 text-muted-foreground">It may have been removed, or your connection may have dropped.</p><button className="btn-primary mt-6" onClick={() => navigate("/")}>Return to my lessons</button></div>;
  }

  const progress = lessonProgress(draft.data);
  const checks = readinessChecks(draft.data);
  const phases = Object.keys(phaseMeta) as PhaseKey[];

  function renderEditor() {
    if (!draft) return null;
    const props = { data: draft.data, onChange: changeData };
    switch (section) {
      case "engage": return <EngageEditor {...props} />;
      case "activate1": return <Activate1Editor {...props} />;
      case "study": return <StudyEditor {...props} goTo={setSection} />;
      case "activate2": return <Activate2Editor {...props} goTo={setSection} />;
      case "reflection": return <ReflectionEditor {...props} goTo={setSection} />;
      case "report": return <ReportView lesson={draft} professorName={user?.name || undefined} />;
    }
  }

  return (
    <div className="min-h-dvh">
      <header className="border-b bg-white">
        <div className="mx-auto max-w-[1500px] px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <button className="icon-button -ml-2" onClick={() => navigate("/")} aria-label="Back to lesson library"><ArrowLeft className="h-5 w-5" /></button>
            <div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h1 className="display-type truncate text-lg font-bold sm:text-xl">{draft.title}</h1><button className="icon-button h-8 w-8" onClick={() => setDetailsOpen(true)} aria-label="Edit lesson details"><Pencil className="h-3.5 w-3.5" /></button></div><p className="truncate text-xs text-muted-foreground">{draft.topic}{draft.course ? ` · ${draft.course}` : ""}</p></div>
            <div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex" aria-live="polite">
              {saveStatus === "saving" ? <><Loader2 className="h-4 w-4 animate-spin" /> Saving…</> : saveStatus === "error" ? <><CloudOff className="h-4 w-4 text-destructive" /> Save failed</> : saveStatus === "unsaved" ? <><Circle className="h-3 w-3" /> Unsaved changes</> : <><Cloud className="h-4 w-4 text-green-700" /> All changes saved</>}
            </div>
            <button className="btn-secondary hidden px-3 sm:inline-flex" onClick={() => saveDraft(draft)} disabled={saveStatus === "saving" || saveStatus === "saved"}><Save className="h-4 w-4" /> Save</button>
            <select className="field ml-1 hidden w-40 md:block" value={draft.status} onChange={(e) => changeMeta({ status: e.target.value as LessonDraft["status"] })} aria-label="Lesson status"><option value="draft">Draft</option><option value="ready">Ready to teach</option><option value="completed">Taught & reflected</option></select>
            <button className="btn-primary" onClick={() => setSection("report")}><FileText className="h-4 w-4" /><span className="hidden sm:inline">Report</span></button>
          </div>
          <div className="mt-3 flex items-center gap-3 sm:hidden"><span className="flex-1 text-xs text-muted-foreground">{saveStatus === "saved" ? "All changes saved" : saveStatus === "saving" ? "Saving…" : saveStatus === "error" ? "Save failed — tap Save" : "Unsaved changes"}</span>{saveStatus !== "saved" && <button className="min-h-9 px-2 text-xs font-bold text-primary" onClick={() => saveDraft(draft)}>Save now</button>}<select className="field min-h-9 w-32 py-1 text-xs" value={draft.status} onChange={(e) => changeMeta({ status: e.target.value as LessonDraft["status"] })} aria-label="Lesson status"><option value="draft">Draft</option><option value="ready">Ready</option><option value="completed">Completed</option></select></div>
          <div className="mt-4 flex items-center gap-3"><Progress value={progress} className="h-1.5 flex-1" /><span className="text-xs font-semibold text-muted-foreground">{progress}%</span><span className="hidden text-xs text-muted-foreground sm:inline">{totalMinutes(draft.data)} min · {draft.data.gaps.length} gaps · {statusLabel(draft.status)}</span></div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1500px] gap-8 px-4 py-6 sm:px-6 lg:px-8 xl:grid-cols-[190px_minmax(0,1fr)_250px]">
        <aside className="min-w-0 xl:sticky xl:top-6 xl:self-start">
          <nav className="flex gap-1 overflow-x-auto pb-2 xl:block xl:space-y-1 xl:overflow-visible" aria-label="Lesson sections">
            {phases.map((key, index) => <button key={key} onClick={() => setSection(key)} className={`flex min-h-12 shrink-0 items-center gap-2 rounded-lg px-3 text-left text-sm transition-colors xl:w-full ${section === key ? "bg-accent font-bold text-accent-foreground" : "hover:bg-white"}`}><span className={`display-type flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-extrabold ${section === key ? "bg-primary text-white" : "bg-secondary"}`}>{phaseMeta[key].short}</span><span className="whitespace-nowrap">{phaseMeta[key].title}</span>{index < 3 && <ChevronRight className="h-3.5 w-3.5 text-muted-foreground xl:hidden" />}</button>)}
            <div className="hidden my-3 border-t xl:block" />
            <button onClick={() => setSection("reflection")} className={`flex min-h-12 shrink-0 items-center gap-2 rounded-lg px-3 text-left text-sm xl:w-full ${section === "reflection" ? "bg-accent font-bold text-accent-foreground" : "hover:bg-white"}`}><BookOpenCheck className="h-4 w-4" /> Reflection</button>
            <button onClick={() => setSection("report")} className={`flex min-h-12 shrink-0 items-center gap-2 rounded-lg px-3 text-left text-sm xl:w-full ${section === "report" ? "bg-accent font-bold text-accent-foreground" : "hover:bg-white"}`}><FileText className="h-4 w-4" /> Report</button>
          </nav>
        </aside>

        <section className="min-w-0">
          <div className="mb-7 max-w-3xl"><p className="section-label text-primary">{sectionInfo[section].eyebrow}</p><h2 className="display-type mt-2 text-2xl font-extrabold sm:text-3xl">{sectionInfo[section].title}</h2><p className="mt-2 text-[15px] text-muted-foreground">{sectionInfo[section].description}</p></div>
          {renderEditor()}
          {section !== "report" && section !== "reflection" && section !== "activate2" && section !== "study" && <div className="mt-8 flex justify-end border-t pt-5"><button className="btn-secondary" onClick={() => setSection(phases[Math.min(phases.indexOf(section), phases.length - 2) + 1])}>Next phase <ChevronRight className="h-4 w-4" /></button></div>}
        </section>

        <aside className="min-w-0 border-t pt-6 xl:sticky xl:top-6 xl:self-start xl:border-t-0 xl:pt-0">
          <div className="flex items-center justify-between"><h3 className="display-type text-sm font-bold">Boomerang check</h3><span className="text-xs font-bold text-primary">{checks.filter((check) => check.complete).length}/{checks.length}</span></div>
          <ul className="mt-4 space-y-3">{checks.map((check) => <li key={check.id} className="flex gap-2.5 text-xs leading-relaxed text-muted-foreground">{check.complete ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-700" /> : <Circle className="mt-0.5 h-4 w-4 shrink-0" />}<span className={check.complete ? "text-foreground" : ""}>{check.label}</span></li>)}</ul>
          <div className="mt-6 border-t pt-5"><div className="flex items-center justify-between text-sm"><span className="text-muted-foreground">Lesson time</span><strong>{totalMinutes(draft.data)} min</strong></div><div className="mt-2 flex items-center justify-between text-sm"><span className="text-muted-foreground">Gaps → Study</span><strong>{draft.data.gaps.filter((gap) => gap.selected).length} linked</strong></div></div>
          {section !== "report" && <button className="btn-secondary mt-5 w-full" onClick={() => setSection("report")}><FileText className="h-4 w-4" /> Preview report</button>}
          <p className="mt-5 text-xs leading-relaxed text-muted-foreground"><Check className="mr-1 inline h-3.5 w-3.5 text-primary" /> Your work is saved to your professor account.</p>
        </aside>
      </div>

      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-h-[92dvh] overflow-y-auto sm:max-w-xl"><DialogHeader><DialogTitle className="display-type flex items-center gap-2 text-xl"><Settings2 className="h-5 w-5" /> Lesson details</DialogTitle><DialogDescription>Changes save automatically to this lesson.</DialogDescription></DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); setDetailsOpen(false); }} className="space-y-4">
            <label className="block text-sm font-semibold">Lesson title<input className="field mt-1.5" value={draft.title} onChange={(e) => changeMeta({ title: e.target.value })} required /></label>
            <div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-semibold">Language topic<input className="field mt-1.5" value={draft.topic} onChange={(e) => changeMeta({ topic: e.target.value })} required /></label><label className="block text-sm font-semibold">Course<input className="field mt-1.5" value={draft.course} onChange={(e) => changeMeta({ course: e.target.value })} /></label><label className="block text-sm font-semibold">Student level<input className="field mt-1.5" value={draft.level} onChange={(e) => changeMeta({ level: e.target.value })} /></label><label className="block text-sm font-semibold">Class size<input className="field mt-1.5" value={draft.studentCount} onChange={(e) => changeMeta({ studentCount: e.target.value })} /></label></div>
            <label className="block text-sm font-semibold">Teaching date<input type="date" className="field mt-1.5" value={draft.classDate} onChange={(e) => changeMeta({ classDate: e.target.value })} /></label>
            <DialogFooter><button className="btn-primary" type="submit">Done</button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
