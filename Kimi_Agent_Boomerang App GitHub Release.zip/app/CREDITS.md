# Credits

- Figtree and Plus Jakarta Sans: Google Fonts, SIL Open Font License.
- Lucide icons: ISC License.
- Interface components: shadcn/ui and Radix UI, MIT License.
- Reference video: supplied by the course brief and embedded from YouTube; no video content is redistributed by the application.
- All lesson content entered by professors remains their own user-generated content.
