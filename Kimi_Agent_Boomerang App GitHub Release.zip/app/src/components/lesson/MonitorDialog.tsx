import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { GapNote, GapType } from "@contracts/lesson";
import { Check, Eye, Pause, Play, Plus, RotateCcw } from "lucide-react";
import { type FormEvent, useEffect, useState } from "react";

function makeId() {
  return typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
}

export function MonitorDialog({ open, onOpenChange, gaps, onAdd }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  gaps: GapNote[];
  onAdd: (gap: GapNote) => void;
}) {
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const [observation, setObservation] = useState("");
  const [neededLanguage, setNeededLanguage] = useState("");
  const [type, setType] = useState<GapType>("vocabulary");
  const [error, setError] = useState("");
  const [added, setAdded] = useState(false);

  useEffect(() => {
    if (!running || !open) return;
    const timer = window.setInterval(() => setSeconds((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [running, open]);

  useEffect(() => {
    if (open) setRunning(true);
  }, [open]);

  function addGap(event: FormEvent) {
    event.preventDefault();
    if (!observation.trim()) {
      setError("Write the exact word, phrase, or error you observed.");
      return;
    }
    onAdd({ id: makeId(), type, observation: observation.trim(), neededLanguage: neededLanguage.trim(), selected: true });
    setObservation("");
    setNeededLanguage("");
    setError("");
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1200);
  }

  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex h-[100dvh] max-w-none flex-col overflow-hidden rounded-none p-0 sm:h-auto sm:max-h-[90dvh] sm:max-w-4xl sm:rounded-xl">
        <DialogHeader className="border-b px-5 py-4 pr-14 text-left sm:px-6">
          <DialogTitle className="display-type flex items-center gap-2 text-xl"><Eye className="h-5 w-5 text-primary" /> Activate 1 · Monitoring mode</DialogTitle>
          <DialogDescription>Listen for need, not mistakes to fix. Do not interrupt or correct.</DialogDescription>
        </DialogHeader>
        <div className="grid min-h-0 flex-1 overflow-y-auto md:grid-cols-[220px_minmax(0,1fr)]">
          <aside className="border-b bg-secondary/55 p-5 md:border-b-0 md:border-r">
            <p className="section-label">Hands-off time</p>
            <div className="display-type mt-2 text-4xl font-bold tabular-nums" aria-live="off">{minutes}:{secs}</div>
            <div className="mt-4 flex gap-2">
              <button className="btn-secondary flex-1 px-3" onClick={() => setRunning((value) => !value)}>{running ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}{running ? "Pause" : "Resume"}</button>
              <button className="icon-button bg-white" onClick={() => { setSeconds(0); setRunning(false); }} aria-label="Reset timer"><RotateCcw className="h-4 w-4" /></button>
            </div>
            <p className="mt-5 text-sm leading-relaxed text-muted-foreground">Move around. Record exact student language. Note where communication breaks down—not every imperfect sentence.</p>
            <div className="mt-5 border-t pt-4 text-sm"><span className="display-type text-2xl font-bold">{gaps.length}</span><span className="ml-2 text-muted-foreground">gaps captured</span></div>
          </aside>
          <div className="p-5 sm:p-6">
            <form onSubmit={addGap} className="border-b pb-6">
              <div className="flex items-center justify-between"><h3 className="display-type font-bold">Capture a language gap</h3>{added && <span className="flex items-center gap-1 text-xs font-bold text-green-700"><Check className="h-4 w-4" /> Added</span>}</div>
              <div className="mt-4 grid gap-4 sm:grid-cols-[150px_minmax(0,1fr)]">
                <label className="text-sm font-semibold">Gap type<select className="field mt-1.5" value={type} onChange={(e) => setType(e.target.value as GapType)}><option value="vocabulary">Vocabulary</option><option value="grammar">Grammar</option><option value="pronunciation">Pronunciation</option><option value="discourse">Discourse</option></select></label>
                <label className="text-sm font-semibold">What did students say or struggle to say?<input autoFocus className="field mt-1.5" value={observation} onChange={(e) => setObservation(e.target.value)} placeholder="e.g. “He go to work at 7”" /></label>
              </div>
              <label className="mt-4 block text-sm font-semibold">Language they needed <span className="font-normal text-muted-foreground">(optional for now)</span><input className="field mt-1.5" value={neededLanguage} onChange={(e) => setNeededLanguage(e.target.value)} placeholder="Third-person -s; “He goes…”" /></label>
              {error && <p className="mt-2 text-sm text-red-700" role="alert">{error}</p>}
              <button className="btn-primary mt-4" type="submit"><Plus className="h-4 w-4" /> Add to gap log</button>
            </form>
            <div className="pt-5">
              <h3 className="section-label">Most recent observations</h3>
              {gaps.length === 0 ? <p className="mt-3 text-sm text-muted-foreground">Your observations will appear here.</p> : (
                <ul className="mt-3 space-y-3">{[...gaps].reverse().slice(0, 4).map((gap) => <li key={gap.id} className="border-l-2 border-primary pl-3"><span className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">{gap.type}</span><p className="text-sm">{gap.observation}</p>{gap.neededLanguage && <p className="mt-1 text-xs text-muted-foreground">Needed: {gap.neededLanguage}</p>}</li>)}</ul>
              )}
            </div>
          </div>
        </div>
        <div className="flex justify-end border-t bg-background px-5 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:px-6"><button className="btn-primary" onClick={() => onOpenChange(false)}>Finish monitoring</button></div>
      </DialogContent>
    </Dialog>
  );
}
