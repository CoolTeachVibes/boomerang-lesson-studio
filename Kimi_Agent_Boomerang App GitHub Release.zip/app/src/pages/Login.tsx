import { Brand } from "@/components/Brand";
import { trpc } from "@/providers/trpc";
import { ArrowRight, BookOpen, Check, Eye, EyeOff, Loader2 } from "lucide-react";
import { type FormEvent, useState } from "react";
import { useNavigate } from "react-router";

export default function Login() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const login = trpc.auth.login.useMutation({
    onSuccess: async (user) => {
      utils.auth.me.setData(undefined, user);
      await utils.lessons.list.invalidate();
      navigate("/");
    },
    onError: (mutationError) => setError(mutationError.message),
  });
  const register = trpc.auth.register.useMutation({
    onSuccess: async (user) => {
      utils.auth.me.setData(undefined, user);
      await utils.lessons.list.invalidate();
      navigate("/");
    },
    onError: (mutationError) => setError(mutationError.message),
  });
  const pending = login.isPending || register.isPending;

  function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (mode === "register" && password.length < 12) {
      setError("Choose a password with at least 12 characters.");
      return;
    }
    if (mode === "login") login.mutate({ email, password });
    else register.mutate({ name, email, password });
  }

  function switchMode() {
    setMode((current) => current === "login" ? "register" : "login");
    setError("");
  }

  return (
    <div className="min-h-dvh bg-background lg:grid lg:grid-cols-[minmax(0,1fr)_480px]">
      <section className="paper-grid relative hidden overflow-hidden border-r p-12 lg:flex lg:flex-col lg:justify-between">
        <Brand />
        <div className="relative z-10 max-w-xl pb-10">
          <p className="section-label text-primary">Disruptive English Teaching</p>
          <h1 className="display-type mt-5 text-5xl font-extrabold leading-[1.08]">Let the first attempt reveal the lesson.</h1>
          <p className="mt-5 max-w-lg text-lg leading-relaxed text-muted-foreground">Plan for communication, capture real language needs, and return students to the task better equipped.</p>
          <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm font-semibold"><span className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Private lesson workspace</span><span className="flex items-center gap-2"><Check className="h-4 w-4 text-primary" /> Two-page reports</span><span className="flex items-center gap-2"><BookOpen className="h-4 w-4 text-primary" /> Method library</span></div>
        </div>
        <p className="text-sm text-muted-foreground">Boomerang ESA · Communication before correction</p>
      </section>

      <main className="flex min-h-dvh items-center justify-center px-5 py-10 sm:px-8">
        <div className="w-full max-w-sm">
          <div className="mb-10 lg:hidden"><Brand /></div>
          <p className="section-label text-primary">{mode === "login" ? "Welcome back" : "Your teaching laboratory"}</p>
          <h2 className="display-type mt-2 text-3xl font-extrabold">{mode === "login" ? "Sign in to your studio" : "Create your account"}</h2>
          <p className="mt-2 text-[15px] text-muted-foreground">{mode === "login" ? "Continue planning and reflecting on your lessons." : "Keep your plans, observations, and reports together."}</p>

          <form onSubmit={submit} className="mt-7 space-y-4">
            {mode === "register" && <label className="block text-sm font-bold">Your name<input autoFocus className="field mt-1.5" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Dr. Maya Chen" minLength={2} maxLength={100} required /></label>}
            <label className="block text-sm font-bold">University or personal email<input autoFocus={mode === "login"} className="field mt-1.5" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="professor@university.edu" required /></label>
            <label className="block text-sm font-bold">Password<span className="relative mt-1.5 block"><input className="field pr-12" type={showPassword ? "text" : "password"} autoComplete={mode === "login" ? "current-password" : "new-password"} value={password} onChange={(event) => setPassword(event.target.value)} placeholder={mode === "register" ? "At least 12 characters" : "Your password"} minLength={mode === "register" ? 12 : 1} maxLength={128} required /><button type="button" className="icon-button absolute right-0 top-0" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></span></label>
            {mode === "register" && <p className="text-xs leading-relaxed text-muted-foreground">Use 12 or more characters. Your password is salted and hashed before storage.</p>}
            {error && <p className="rounded-lg bg-red-50 px-3 py-2.5 text-sm text-red-700" role="alert">{error}</p>}
            <button className="btn-primary w-full" type="submit" disabled={pending}>{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}{pending ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
          </form>

          <div className="mt-6 border-t pt-5 text-center text-sm text-muted-foreground">{mode === "login" ? "New to Boomerang?" : "Already have an account?"}<button className="ml-1.5 min-h-11 font-bold text-primary hover:underline" onClick={switchMode}>{mode === "login" ? "Create an account" : "Sign in"}</button></div>
        </div>
      </main>
    </div>
  );
}
