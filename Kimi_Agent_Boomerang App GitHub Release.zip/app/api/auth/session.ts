import * as jose from "jose";
import * as cookie from "cookie";
import { Session } from "@contracts/constants";
import { env } from "../lib/env";
import { findUserById } from "../queries/users";

const JWT_ALG = "HS256";

function secretKey() {
  return new TextEncoder().encode(env.appSecret);
}

export async function createSessionToken(userId: number) {
  return new jose.SignJWT({ sub: String(userId) })
    .setProtectedHeader({ alg: JWT_ALG })
    .setIssuedAt()
    .setExpirationTime(`${Session.maxAgeMs / 1000}s`)
    .sign(secretKey());
}

export async function authenticateRequest(headers: Headers) {
  const cookies = cookie.parse(headers.get("cookie") || "");
  const token = cookies[Session.cookieName];
  if (!token) return null;
  try {
    const { payload } = await jose.jwtVerify(token, secretKey(), { algorithms: [JWT_ALG] });
    const userId = Number(payload.sub);
    if (!Number.isInteger(userId) || userId <= 0) return null;
    return (await findUserById(userId)) ?? null;
  } catch {
    return null;
  }
}
